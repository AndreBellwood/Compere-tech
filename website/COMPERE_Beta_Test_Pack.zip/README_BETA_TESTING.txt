==============================================================
COMPèRE HVAC Technical Compliance Terminal - Beta Test Pack
==============================================================

Welcome to the COMPèRE Beta Evaluation!

This test pack contains the complete technical specification schedule
and four comprehensive international vendor bids for:

  Project: Refurbishment of The Square, Buildings B and C
  Tender:  NP 129 HVAC Specification Parameter Schedule

Files included:
1. Schedule_Refurbishment for TheSquare.pdf
   -> Upload as 'Specification' (Step 1)
      Covers air handling units, downflow precision cooling (CRAC),
      split units, decommissioning, wet services, and BMS controls.

2. ALPHA Quote. The Square.pdf
   -> Upload as 'Vendor Submission' (Step 2)
      Bid from Alpha Thermal Solutions, Inc. (USD)

3. Quote_SHUNTER_THE_SQUARE.pdf
   -> Upload as 'Vendor Submission' (Step 2)
      Bid from Shunter Climate K.K. (JPY)

4. The Square. Farrier 241126.pdf
   -> Upload as 'Vendor Submission' (Step 2)
      Bid from Farrier Climate Systems Limited (GBP)

5. TheSquare_RAIN Quote.pdf
   -> Upload as 'Vendor Submission' (Step 2)
      Bid from Rain Climate Australia Pty Ltd (AUD)

Quick Testing Workflow:
1. Open the COMPèRE Terminal (https://compere-tech.streamlit.app).
2. Under 'Step 1: Staged Specification', upload:
   'Schedule_Refurbishment for TheSquare.pdf'
3. Under 'Step 2: Staged Vendor Submissions', upload the 4 vendor PDFs:
   - 'ALPHA Quote. The Square.pdf'
   - 'Quote_SHUNTER_THE_SQUARE.pdf'
   - 'The Square. Farrier 241126.pdf'
   - 'TheSquare_RAIN Quote.pdf'
4. Click 'Execute Compliance & Adjudication Audit'.
5. Review the side-by-side compliance matrix, multi-currency conversions,
   engineering parameter tolerances, and scorecards.
6. Click 'Download Corporate PDF Report' to inspect the final audit report.

For support or feedback, contact the COMPèRE evaluation team.
