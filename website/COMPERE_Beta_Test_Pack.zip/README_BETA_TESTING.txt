==============================================================
COMPèRE HVAC Technical Compliance Terminal - Beta Test Pack
==============================================================

Welcome to the COMPèRE Beta Evaluation!

This test pack provides a calibrated engineering specification and
four realistic vendor tender bids for an Air Handling Unit (AHU) package:

Files included:
1. 01_Specification_AHU_Consulting_Spec.pdf  -> Upload as Specification
2. 02_Vendor_Offer_ThermOpac.pdf            -> Upload as Vendor Submission 1
3. 03_Vendor_Offer_Carrier.pdf              -> Upload as Vendor Submission 2
4. 04_Vendor_Offer_Trane.pdf                -> Upload as Vendor Submission 3
5. 05_Vendor_Offer_Daikin.pdf               -> Upload as Vendor Submission 4

Quick Testing Workflow:
1. Open the COMPèRE Terminal (Streamlit).
2. In 'Step 1: Staged Specification', upload '01_Specification_AHU_Consulting_Spec.pdf'.
3. In 'Step 2: Staged Vendor Submissions', upload the 4 vendor PDFs.
4. Click 'Execute Compliance & Adjudication Audit'.
5. Review the side-by-side compliance matrix, dynamic capacity checks, and scorecards.
6. Click 'Download Corporate PDF Report' to generate your audit-ready PDF ledger.

For feedback or questions, contact your evaluation coordinator.
